import { useRecoilValue } from "recoil";
import { authState } from "../../authState";
import useSWR from "swr";
import axios from "axios";
import React, { useState, useEffect } from "react";

export const useEmployeeData = ({
  initialPage = 1,
  length = 10,
  sort_order = "asc",
  sort_by = "name",
} = {}) => {
  const [page, setPage] = useState(initialPage);
  const auth = useRecoilValue(authState);
  const token = auth?.token;
  
  const queryString = `?length=${length}&page=${page}&sort_order=${sort_order}&sort_by=${sort_by}`;
  const url = `https://core-skill-test.webc.in/employee-portal/api/v1/employee${queryString}`;
  
  // Store the previous response so we can use it as fallback
  const [prevData, setPrevData] = useState(null);

  const fetcher = (url) =>
    axios
      .get(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => res.data);

  const { data, error, isLoading, mutate } = useSWR(
    token ? url : null,
    fetcher,
    {
      keepPreviousData : true// use previous data while new data loads
    }
  );

  // Update the previous data when new data arrives
  useEffect(() => {
    if (data) {
      setPrevData(data);
    }
  }, [data]);

  const employees = data?.data?.rows?.data || [];
  const totalPages = data?.data?.rows?.last_page || 1;

  return { data: employees, page, totalPages, setPage, error, isLoading, mutate };
};
