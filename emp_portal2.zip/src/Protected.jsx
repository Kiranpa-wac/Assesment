import React from "react";
import { useRecoilValue } from "recoil";
import { authState } from "./authState";
import  {Navigate}  from "react-router-dom";

const ProtectedRoute = ({ children }) => {
  const auth = useRecoilValue(authState);
  return auth && auth.token ? children : <Navigate to="/login" replace />;
};

export default ProtectedRoute;
