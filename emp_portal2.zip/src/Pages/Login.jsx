// Login.js
import React, { useState } from 'react';
import axios from 'axios';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import { authState } from '../authState';
import { Navigate, useNavigate } from 'react-router-dom';
import { Form } from 'informed';
import CustomField from '../Components/CustomLoginField';
import { Eye, EyeOff } from 'lucide-react';
import './Login.css';

function Login() {
  const setAuth = useSetRecoilState(authState);
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const user = useRecoilValue(authState);
  if (user?.token) {
    return <Navigate to='/' replace />;
  }

  // Email validation function
  const validateEmail = (value) => {
    if (!value) {
      return 'Email is required';
    }
    // Simple regex to validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      return 'Invalid email address';
    }
  };

  const handleLogin = async (values) => {
    try {
      console.log(values);
      const response = await axios.post(
        'https://core-skill-test.webc.in/employee-portal/api/v1/auth/login',
        {
          username: values.values.email,
          password: values.values.password,
        }
      );
      console.log(response);
      const token = response.data.data.token;

      // Save the token in Recoil (and localStorage via the effect)
      setAuth({ token });

      // Redirect to home using replace so the login page is not in history
      navigate('/', { replace: true });
    } catch (err) {
      console.error(err);
      setError(err.message || 'Login failed!');
      alert('Login failed!');
    }
  };

  return (
    <div className="login-container">
      <Form className="login-form" onSubmit={handleLogin}>
        <h2>Login</h2>
        <CustomField
          name="email"
          label="Email"
          fieldType="email"
          validate={validateEmail}
          required
          placeholder="Enter your email"
        />
        <CustomField
          name="password"
          label="Password"
          fieldType={showPassword ? "text" : "password"}
          required
          placeholder="Enter your password"
          append={
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="toggle-password-btn"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          }
        />
        <button type="submit" className="submit-button">
          Login
        </button>
        {error && <div className="error-message">{error}</div>}
      </Form>
    </div>
  );
}

export default Login;
